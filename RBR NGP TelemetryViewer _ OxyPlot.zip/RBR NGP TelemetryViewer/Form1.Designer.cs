﻿
namespace RBR_NGP_TelemetryViewer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Obsolete]
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.TimeDiffirenceChart = new ScottPlot.FormsPlot();
            this.RaceTrack = new ScottPlot.FormsPlot();
            this.EngineDataChart = new ScottPlot.FormsPlot();
            this.GForcesChart = new ScottPlot.FormsPlot();
            this.SpeedChart = new ScottPlot.FormsPlot();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.RaceTrackOP = new OxyPlot.WindowsForms.PlotView();
            this.EngineOP = new OxyPlot.WindowsForms.PlotView();
            this.GForcesOP = new OxyPlot.WindowsForms.PlotView();
            this.SpeedOP = new OxyPlot.WindowsForms.PlotView();
            this.TimeDiffOP = new OxyPlot.WindowsForms.PlotView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.plotView4 = new OxyPlot.WindowsForms.PlotView();
            this.plotView3 = new OxyPlot.WindowsForms.PlotView();
            this.plotView2 = new OxyPlot.WindowsForms.PlotView();
            this.plotView1 = new OxyPlot.WindowsForms.PlotView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.firstMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.plotView5 = new OxyPlot.WindowsForms.PlotView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Location = new System.Drawing.Point(0, 564);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 15, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1232, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 26);
            this.tabControl1.MaximumSize = new System.Drawing.Size(1536, 864);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1232, 626);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.TimeDiffirenceChart);
            this.tabPage1.Controls.Add(this.RaceTrack);
            this.tabPage1.Controls.Add(this.EngineDataChart);
            this.tabPage1.Controls.Add(this.GForcesChart);
            this.tabPage1.Controls.Add(this.SpeedChart);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1224, 597);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(939, 6);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(280, 278);
            this.dataGridView1.TabIndex = 5;
            // 
            // TimeDiffirenceChart
            // 
            this.TimeDiffirenceChart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TimeDiffirenceChart.Location = new System.Drawing.Point(54, -2);
            this.TimeDiffirenceChart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TimeDiffirenceChart.Name = "TimeDiffirenceChart";
            this.TimeDiffirenceChart.Size = new System.Drawing.Size(894, 95);
            this.TimeDiffirenceChart.TabIndex = 4;
            // 
            // RaceTrack
            // 
            this.RaceTrack.Location = new System.Drawing.Point(957, 354);
            this.RaceTrack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RaceTrack.Name = "RaceTrack";
            this.RaceTrack.Size = new System.Drawing.Size(266, 246);
            this.RaceTrack.TabIndex = 3;
            // 
            // EngineDataChart
            // 
            this.EngineDataChart.Location = new System.Drawing.Point(0, 414);
            this.EngineDataChart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EngineDataChart.Name = "EngineDataChart";
            this.EngineDataChart.Size = new System.Drawing.Size(948, 185);
            this.EngineDataChart.TabIndex = 2;
            // 
            // GForcesChart
            // 
            this.GForcesChart.Location = new System.Drawing.Point(0, 246);
            this.GForcesChart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.GForcesChart.Name = "GForcesChart";
            this.GForcesChart.Size = new System.Drawing.Size(948, 162);
            this.GForcesChart.TabIndex = 1;
            // 
            // SpeedChart
            // 
            this.SpeedChart.Location = new System.Drawing.Point(0, 102);
            this.SpeedChart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SpeedChart.Name = "SpeedChart";
            this.SpeedChart.Size = new System.Drawing.Size(948, 139);
            this.SpeedChart.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.RaceTrackOP);
            this.tabPage2.Controls.Add(this.EngineOP);
            this.tabPage2.Controls.Add(this.GForcesOP);
            this.tabPage2.Controls.Add(this.SpeedOP);
            this.tabPage2.Controls.Add(this.TimeDiffOP);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1224, 597);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(981, 172);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1020, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // RaceTrackOP
            // 
            this.RaceTrackOP.Location = new System.Drawing.Point(982, 328);
            this.RaceTrackOP.Name = "RaceTrackOP";
            this.RaceTrackOP.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.RaceTrackOP.Size = new System.Drawing.Size(239, 269);
            this.RaceTrackOP.TabIndex = 4;
            this.RaceTrackOP.Text = "plotView1";
            this.RaceTrackOP.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.RaceTrackOP.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.RaceTrackOP.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // EngineOP
            // 
            this.EngineOP.Location = new System.Drawing.Point(0, 457);
            this.EngineOP.Name = "EngineOP";
            this.EngineOP.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.EngineOP.Size = new System.Drawing.Size(975, 140);
            this.EngineOP.TabIndex = 3;
            this.EngineOP.Text = "plotView1";
            this.EngineOP.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.EngineOP.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.EngineOP.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.EngineOP.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.EngineOP_MouseDoubleClick);
            this.EngineOP.MouseCaptureChanged += new System.EventHandler(this.EngineOP_MouseCaptureChanged);
            // 
            // GForcesOP
            // 
            this.GForcesOP.Location = new System.Drawing.Point(0, 265);
            this.GForcesOP.Name = "GForcesOP";
            this.GForcesOP.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.GForcesOP.Size = new System.Drawing.Size(975, 186);
            this.GForcesOP.TabIndex = 2;
            this.GForcesOP.Text = "plotView1";
            this.GForcesOP.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.GForcesOP.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.GForcesOP.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // SpeedOP
            // 
            this.SpeedOP.Location = new System.Drawing.Point(0, 101);
            this.SpeedOP.Name = "SpeedOP";
            this.SpeedOP.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.SpeedOP.Size = new System.Drawing.Size(975, 158);
            this.SpeedOP.TabIndex = 1;
            this.SpeedOP.Text = "plotView1";
            this.SpeedOP.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.SpeedOP.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.SpeedOP.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // TimeDiffOP
            // 
            this.TimeDiffOP.Location = new System.Drawing.Point(0, 0);
            this.TimeDiffOP.Name = "TimeDiffOP";
            this.TimeDiffOP.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.TimeDiffOP.Size = new System.Drawing.Size(975, 94);
            this.TimeDiffOP.TabIndex = 0;
            this.TimeDiffOP.Text = "plotView1";
            this.TimeDiffOP.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.TimeDiffOP.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.TimeDiffOP.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.plotView5);
            this.tabPage3.Controls.Add(this.plotView4);
            this.tabPage3.Controls.Add(this.plotView3);
            this.tabPage3.Controls.Add(this.plotView2);
            this.tabPage3.Controls.Add(this.plotView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1224, 597);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // plotView4
            // 
            this.plotView4.Location = new System.Drawing.Point(173, 304);
            this.plotView4.Margin = new System.Windows.Forms.Padding(2);
            this.plotView4.MaximumSize = new System.Drawing.Size(320, 320);
            this.plotView4.MinimumSize = new System.Drawing.Size(80, 80);
            this.plotView4.Name = "plotView4";
            this.plotView4.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plotView4.Size = new System.Drawing.Size(188, 132);
            this.plotView4.TabIndex = 3;
            this.plotView4.Text = "plotView4";
            this.plotView4.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plotView4.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plotView4.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // plotView3
            // 
            this.plotView3.Location = new System.Drawing.Point(559, 304);
            this.plotView3.Margin = new System.Windows.Forms.Padding(2);
            this.plotView3.MaximumSize = new System.Drawing.Size(320, 320);
            this.plotView3.MinimumSize = new System.Drawing.Size(80, 80);
            this.plotView3.Name = "plotView3";
            this.plotView3.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plotView3.Size = new System.Drawing.Size(188, 132);
            this.plotView3.TabIndex = 2;
            this.plotView3.Text = "plotView3";
            this.plotView3.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plotView3.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plotView3.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // plotView2
            // 
            this.plotView2.Location = new System.Drawing.Point(550, 132);
            this.plotView2.Margin = new System.Windows.Forms.Padding(2);
            this.plotView2.MaximumSize = new System.Drawing.Size(320, 320);
            this.plotView2.MinimumSize = new System.Drawing.Size(80, 80);
            this.plotView2.Name = "plotView2";
            this.plotView2.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plotView2.Size = new System.Drawing.Size(188, 132);
            this.plotView2.TabIndex = 1;
            this.plotView2.Text = "plotView2";
            this.plotView2.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plotView2.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plotView2.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // plotView1
            // 
            this.plotView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.plotView1.Location = new System.Drawing.Point(173, 135);
            this.plotView1.Margin = new System.Windows.Forms.Padding(2);
            this.plotView1.MaximumSize = new System.Drawing.Size(320, 320);
            this.plotView1.MinimumSize = new System.Drawing.Size(80, 80);
            this.plotView1.Name = "plotView1";
            this.plotView1.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plotView1.Size = new System.Drawing.Size(188, 129);
            this.plotView1.TabIndex = 0;
            this.plotView1.Text = "plotView1";
            this.plotView1.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plotView1.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plotView1.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstMenuToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1232, 28);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // firstMenuToolStripMenuItem
            // 
            this.firstMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFileToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.firstMenuToolStripMenuItem.Name = "firstMenuToolStripMenuItem";
            this.firstMenuToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.firstMenuToolStripMenuItem.Text = "FIle";
            // 
            // openFileToolStripMenuItem
            // 
            this.openFileToolStripMenuItem.Name = "openFileToolStripMenuItem";
            this.openFileToolStripMenuItem.Size = new System.Drawing.Size(155, 26);
            this.openFileToolStripMenuItem.Text = "Open File";
            this.openFileToolStripMenuItem.Click += new System.EventHandler(this.openFileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(155, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(133, 26);
            this.aboutToolStripMenuItem1.Text = "About";
            // 
            // plotView5
            // 
            this.plotView5.Location = new System.Drawing.Point(0, 0);
            this.plotView5.Name = "plotView5";
            this.plotView5.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plotView5.Size = new System.Drawing.Size(1221, 68);
            this.plotView5.TabIndex = 4;
            this.plotView5.Text = "DistancePlot";
            this.plotView5.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plotView5.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plotView5.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1232, 586);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RBR NGP Telemetry Viewer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem firstMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private ScottPlot.FormsPlot RaceTrack;
        private ScottPlot.FormsPlot EngineDataChart;
        private ScottPlot.FormsPlot GForcesChart;
        private ScottPlot.FormsPlot SpeedChart;
        private OxyPlot.WindowsForms.PlotView RaceTrackOP;
        private OxyPlot.WindowsForms.PlotView EngineOP;
        private OxyPlot.WindowsForms.PlotView GForcesOP;
        private OxyPlot.WindowsForms.PlotView SpeedOP;
        private OxyPlot.WindowsForms.PlotView TimeDiffOP;
        public ScottPlot.FormsPlot TimeDiffirenceChart;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage3;
        private OxyPlot.WindowsForms.PlotView plotView1;
        private OxyPlot.WindowsForms.PlotView plotView4;
        private OxyPlot.WindowsForms.PlotView plotView3;
        private OxyPlot.WindowsForms.PlotView plotView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private OxyPlot.WindowsForms.PlotView plotView5;
    }
}

