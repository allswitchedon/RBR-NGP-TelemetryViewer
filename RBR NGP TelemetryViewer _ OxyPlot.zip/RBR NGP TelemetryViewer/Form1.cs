﻿using OxyPlot.Axes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RBR_NGP_TelemetryViewer
{
    public partial class Form1 : Form
    {
        OxyPlot.PlotModel SpeedOPModel = new OxyPlot.PlotModel();
        OxyPlot.PlotModel TimeDiffOPModel = new OxyPlot.PlotModel();
        OxyPlot.PlotModel EngineOPModel = new OxyPlot.PlotModel();
        OxyPlot.PlotModel RaceTrackOPModel = new OxyPlot.PlotModel();
        OxyPlot.PlotModel GForcesOPModel = new OxyPlot.PlotModel();
        OxyPlot.PlotModel DistanceOPModel = new OxyPlot.PlotModel();
        List<double> test1 = new List<double>();
        List<double> test2 = new List<double>();
        List<double> test1_1 = new List<double>();
        List<double> test2_1 = new List<double>();
        List<double> test1_2 = new List<double>();
        List<double> test2_2 = new List<double>();
        List<double> test3 = new List<double>();
        List<double> testX = new List<double>();
        List<double> testY = new List<double>();
        List<double> time_diff = new List<double>();
        List<double> distance = new List<double>();
        List<double> position_x_dist = new List<double>();
        List<double> position_y_dist = new List<double>();
        int run = 1;
        double firsttime, secondtime;
        DataTable testvalues = new DataTable();
        double max_speed;
        double max_rpm;
        double racetime;
        int trackleght;

        public Form1()
        {
            InitializeComponent();
            testvalues.Columns.Add(" ");
            testvalues.Rows.Add("Reaction Time");
            testvalues.Rows.Add("Maximum Speed");
            testvalues.Rows.Add("Distance");
            testvalues.Rows.Add("Maximum RPM");
            testvalues.Rows.Add("Open Time");
            testvalues.Rows.Add("Track Leght");
            testvalues.Rows.Add("Visible");

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var starttime = DateTime.Now.Ticks;
            List<string> columnsname = new List<string>();
            List<List<double>> telemetrydata = new List<List<double>>();
            OpenFileDialog selectfile = new OpenFileDialog();
            selectfile.ShowDialog();
            if (File.Exists(selectfile.FileName))
            {
                RBRTelemetryFile.Parse.test(selectfile.FileName);
                columnsname = RBRTelemetryFile.Parse.test1();
                telemetrydata = RBRTelemetryFile.Parse.test2();

            }
            else goto End;
            //SpeedChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), telemetrydata[columnsname.FindIndex("speed".StartsWith)].ToArray());



            ToDistance.Get.Convert(columnsname, telemetrydata, run);
            distance = ToDistance.Get.distance_int();
            position_x_dist = ToDistance.Get.position_x_dist();
            position_y_dist = ToDistance.Get.position_y_dist();
            if (run >= 2)
            {
                var TimeDiffOPLine = new OxyPlot.Series.LineSeries();
                time_diff = ToDistance.Get.time_difference();
                //TimeDiffirenceChart.Plot.AddScatterLines(distance.ToArray(), time_diff.ToArray());
                for (int i = 0; i < time_diff.Count; i++)
                {
                    TimeDiffOPLine.Points.Add(new OxyPlot.DataPoint(distance[i], time_diff[i]));
                }

                TimeDiffOPModel.Series.Add(TimeDiffOPLine);
                TimeDiffirenceChart.Plot.AddHorizontalLine(0, color: Color.Black);
                DataTable check_dt = new DataTable();
                check_dt.Columns.Add("i");
                check_dt.Columns.Add("dist");
                check_dt.Columns.Add("time");
                check_dt.Columns.Add("pos_x");
                check_dt.Columns.Add("pos_y");

                for (int i = 0; i < distance.Count; i++)
                {
                    check_dt.Rows.Add(i, distance[i], time_diff[i], position_x_dist[i], position_y_dist[i]);
                }
                dataGridView2.DataSource = check_dt;
            }

            label1.Text += "\n" + "Run: " + run.ToString() + "\n" + "Distance: " + distance.Count.ToString() + " | " + "PosX: " + position_x_dist.Count.ToString() + " | " + "PosY: " + position_y_dist.Count.ToString();




            double[] speed = telemetrydata[columnsname.FindIndex("speed".StartsWith)].ToArray();
            double[] driveLineLocation = telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray();
            double[] raceTime = telemetrydata[columnsname.FindIndex("raceTime".StartsWith)].ToArray();
            double[] engineRotation = telemetrydata[columnsname.FindIndex("engineRotation".StartsWith)].ToArray();
            double[] position_x = telemetrydata[columnsname.FindIndex("position.x".StartsWith)].ToArray();
            double[] position_y = telemetrydata[columnsname.FindIndex("position.y".StartsWith)].ToArray();
            double[] position_z = telemetrydata[columnsname.FindIndex("position.z".StartsWith)].ToArray();
            double[] GForce_X = telemetrydata[columnsname.FindIndex("vecAvgLinearAccelerationCar.x".StartsWith)].ToArray();
            double[] GForce_Y = telemetrydata[columnsname.FindIndex("vecAvgLinearAccelerationCar.y".StartsWith)].ToArray();
            double[] Speed_X = telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.x".StartsWith)].ToArray();
            double[] Speed_Y = telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.y".StartsWith)].ToArray();
            double[] Speed_Z = telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.z".StartsWith)].ToArray();
            double[] SpeedAdditional_X = telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)].ToArray();
            double[] SpeedAdditional_Y = telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)].ToArray();
            double[] SpeedAdditional_Z = telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)].ToArray();
            double[] Speed_XYZ = new double[driveLineLocation.Length];
            double[] Speed_XYZ2 = new double[driveLineLocation.Length];
            max_rpm = engineRotation.Max();
            racetime = raceTime.Max();
            var racetime_index = Array.IndexOf(raceTime, racetime);
            trackleght = (int)(driveLineLocation[racetime_index]);

            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                Speed_XYZ2[i] = Math.Sqrt(Math.Pow(Speed_X[i], 2) + Math.Pow(Speed_Y[i], 2) + Math.Pow(Speed_Z[i], 2)) * 3.6;

                //Speed_XYZ2[i] = Math.Sqrt(Math.Pow(telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.x".StartsWith)][i], 2) + Math.Pow(telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.y".StartsWith)][i], 2) + Math.Pow(telemetrydata[columnsname.FindIndex("vecLinearVelocityCar.z".StartsWith)][i], 2) + Math.Pow(telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)][i], 2) + Math.Pow(telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)][i], 2) + Math.Pow(telemetrydata[columnsname.FindIndex("vecAngularVelocityCar.x".StartsWith)][i], 2)) * 3.6;
            }
            max_speed = Speed_XYZ2.Max();
            //ScottPlot
            SpeedChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), speed, label: "XYZ");
            
            SpeedChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), Speed_XYZ2, label: "XYZ2");
            SpeedChart.Plot.Legend();
            EngineDataChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), telemetrydata[columnsname.FindIndex("engineRotation".StartsWith)].ToArray());
            RaceTrack.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("position.x".StartsWith)].ToArray(), telemetrydata[columnsname.FindIndex("position.y".StartsWith)].ToArray());
            GForcesChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), telemetrydata[columnsname.FindIndex("vecAvgLinearAccelerationCar.x".StartsWith)].ToArray());
            GForcesChart.Plot.AddScatterLines(telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray(), telemetrydata[columnsname.FindIndex("vecAvgLinearAccelerationCar.y".StartsWith)].ToArray());
            TimeDiffirenceChart.Plot.Frameless();
            SpeedChart.Plot.Frameless();
            GForcesChart.Plot.Frameless();
            EngineDataChart.Plot.Frameless();
            TimeDiffirenceChart.Plot.YAxis.Hide(false);
            SpeedChart.Plot.YAxis.Hide(false);
            GForcesChart.Plot.YAxis.Hide(false);
            EngineDataChart.Plot.XAxis.Hide(false);
            EngineDataChart.Plot.YAxis.Hide(false);
            RaceTrack.Plot.Frameless();
            
            SpeedChart.Refresh();
            EngineDataChart.Refresh();
            RaceTrack.Refresh();
            GForcesChart.Refresh();
            //ScottPlotEND

            var GForcesOPLineX = new OxyPlot.Series.LineSeries();
            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                GForcesOPLineX.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], GForce_X[i]));
            }
            var GForcesOPLineY = new OxyPlot.Series.LineSeries();
            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                GForcesOPLineY.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], GForce_Y[i]));
            }
            GForcesOPModel.Series.Add(GForcesOPLineX);
            GForcesOPModel.Series.Add(GForcesOPLineY);

            var SpeedOPLine = new OxyPlot.Series.LineSeries { Title = "WheelSpeed" };
            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                SpeedOPLine.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], speed[i]));
            }
            var SpeedOPLine2 = new OxyPlot.Series.LineSeries { Title = RaceTime.ToString(telemetrydata[columnsname.FindIndex("raceTime".StartsWith)].Max()) };
            for (int i = 0; i < Speed_XYZ2.Length; i++)
            {
                SpeedOPLine2.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], Speed_XYZ2[i]));
            }
            var SpeedOPLine3 = new OxyPlot.Series.LineSeries();

            //SpeedOPModel.Series.Add(SpeedOPLine);
            SpeedOPModel.Series.Add(SpeedOPLine2);
            SpeedOPModel.Legends.Add(new OxyPlot.Legends.Legend { LegendPosition = OxyPlot.Legends.LegendPosition.TopLeft });



            //var TimeDiffOPLine = new OxyPlot.Series.LineSeries();
            //for (int i = 0; i < driveLineLocation.Length; i++)
            //{
            //    TimeDiffOPLine.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], raceTime[i]));
            //}
            //TimeDiffOPModel.Series.Add(TimeDiffOPLine);

            var RaceTrackOPLine = new OxyPlot.Series.LineSeries { Title = RaceTime.ToString(telemetrydata[columnsname.FindIndex("raceTime".StartsWith)].Max()) };
            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                RaceTrackOPLine.Points.Add(new OxyPlot.DataPoint(position_x[i], position_y[i]));
            }
            RaceTrackOPModel.Series.Add(RaceTrackOPLine);
            RaceTrackOPModel.Legends.Add(new OxyPlot.Legends.Legend { LegendPosition = OxyPlot.Legends.LegendPosition.TopLeft });


            var EngineOPLine = new OxyPlot.Series.LineSeries();
            for (int i = 0; i < driveLineLocation.Length; i++)
            {
                EngineOPLine.Points.Add(new OxyPlot.DataPoint(driveLineLocation[i], engineRotation[i]));
            }
            EngineOPModel.Series.Add(EngineOPLine);

            
            var heightOPLine = new OxyPlot.Series.LineSeries();
            for (int o = 0; o < driveLineLocation.Length; o++) 
            {                heightOPLine.Points.Add(new OxyPlot.DataPoint(driveLineLocation[o], position_z[o]));
        }
            DistanceOPModel.Series.Add(heightOPLine);
            plotView5.Model = DistanceOPModel;


            if (run == 1)
            {

                TimeDiffOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    IsAxisVisible = false,
                    MajorGridlineStyle = OxyPlot.LineStyle.Dot,
                    MajorGridlineColor = OxyPlot.OxyColors.Gray,
                    MinorGridlineStyle = OxyPlot.LineStyle.Dot,
                    MinorGridlineColor = OxyPlot.OxyColors.Gray,
                });
                TimeDiffOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Right,
                    IsAxisVisible = true,
                    MajorGridlineStyle = OxyPlot.LineStyle.Dot,
                    MajorGridlineColor = OxyPlot.OxyColors.Black,
                    MinorGridlineStyle = OxyPlot.LineStyle.Dot,
                    MinorGridlineColor = OxyPlot.OxyColors.Gray
                });


                EngineOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    IsAxisVisible = true
                });
                EngineOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Right,
                    IsAxisVisible = true
                });

                SpeedOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    IsAxisVisible = false
                });
                SpeedOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Right,
                    IsAxisVisible = true
                });

                GForcesOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    IsAxisVisible = false
                });
                GForcesOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Right,
                    IsAxisVisible = true
                });


                RaceTrackOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    IsAxisVisible = false
                });
                RaceTrackOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Left,
                    IsAxisVisible = false
                });

                DistanceOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Bottom,
                    AxisDistance = -15,
                    AxislineStyle = OxyPlot.LineStyle.None,
                    AxisTickToLabelDistance = 15,
                    TickStyle = OxyPlot.Axes.TickStyle.None,
                    
                    IsAxisVisible = true
                });
                DistanceOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Right,
                    IsAxisVisible = false
                });
                DistanceOPModel.Axes.Add(new LinearAxis()
                {
                    Position = AxisPosition.Left,
                    IsAxisVisible = false
                });




                EngineOP.Model = EngineOPModel;
                RaceTrackOP.Model = RaceTrackOPModel;
                GForcesOP.Model = GForcesOPModel;
                SpeedOP.Model = SpeedOPModel;
                TimeDiffOP.Model = TimeDiffOPModel;
            }
            if (run >= 2)
            {
                EngineOP.OnModelChanged();
                RaceTrackOP.OnModelChanged();
                GForcesOP.OnModelChanged();
                SpeedOP.OnModelChanged();
                TimeDiffOP.OnModelChanged();

                TimeDiffirenceChart.Plot.AddScatterLines(distance.ToArray(), time_diff.ToArray());
                TimeDiffirenceChart.Refresh();



            }
        End: var endTime = DateTime.Now.Ticks;

            var test12345 = telemetrydata[columnsname.FindIndex("driveLineLocation".StartsWith)].ToArray();
            var startposition = test12345[1];
            var lastindex = Array.LastIndexOf(test12345, startposition);
            var racestart = telemetrydata[columnsname.FindIndex("raceTime".StartsWith)][lastindex];
            double endtime2 = (double)(endTime);
            double starttime2 = (double)(starttime);
            double timerun = (endtime2 - starttime2) / 10000000;
            //testvalues.Rows[0][run] = racestart;
            //testvalues.Rows[1][run] = max_speed.ToString("0.0");
            //testvalues.Rows[2][run] = test12345.Max();
            //testvalues.Rows[3][run] = max_rpm;
            //testvalues.Rows[4][run] = timerun;
            //testvalues.Rows[5][run] = trackleght;
            //testvalues.Rows[6][run] = new CheckBox();
            //label1.Text = racestart.ToString();

            //label1.Text = timerun.ToString("0.000");
            RBRTelemetryFile.Parse.ClearData();
            //if (run == 1)
            //{
            EngineOPModel.Axes[0].AxisChanged += DefaultXAxis_AxisChanged;
            //}
            run++;


            
            
        }

        public void DefaultXAxis_AxisChanged(object sender, AxisChangedEventArgs e)
        {
            try
            {
                var min = EngineOP.Model.Axes[0].ActualMinimum;
                var max = EngineOP.Model.Axes[0].ActualMaximum;
                var center =    (int) (max + min) / 2;
                var delta = (int) (max - min)/4;
                double tdmin = 0;double tdmax = 0;
                tdmin = time_diff[(int)min];
                tdmax = time_diff[(int)max];
                for (int h=(int)min; h<=(int)max; h++)
                {
                    if (tdmin > time_diff[h])
                        tdmin = time_diff[h];
                    if (tdmax < time_diff[h])
                        tdmax = time_diff[h];
                }
                TimeDiffOP.Model.Axes[0].Zoom(min, max);
                TimeDiffOP.Model.Axes[1].Zoom(tdmin-0.1, tdmax+0.1);
                SpeedOP.Model.Axes[0].Zoom(min, max);
                GForcesOP.Model.Axes[0].Zoom(min, max);
                RaceTrackOP.Model.Axes[0].Zoom(position_x_dist[center]-delta, position_x_dist[center] + delta);
                RaceTrackOP.Model.Axes[1].Zoom(position_y_dist[center] -delta, position_y_dist[center] +delta);
                TimeDiffOP.OnModelChanged();
                SpeedOP.OnModelChanged();
                GForcesOP.OnModelChanged();
                RaceTrackOP.OnModelChanged();
                label1.Text = center.ToString() +"\n" + RaceTrackOP.Model.Axes[0].ActualMaximum.ToString();
            }
            catch { }
        }

        private void EngineOP_MouseCaptureChanged(object sender, EventArgs e)
        {
            var min = EngineOP.Model.Axes[0].ActualMinimum;
            var max = EngineOP.Model.Axes[0].ActualMaximum;
            TimeDiffOP.Model.Axes[0].Zoom(min, max);
            SpeedOP.Model.Axes[0].Zoom(min, max);
            GForcesOP.Model.Axes[0].Zoom(min, max);
            RaceTrackOP.Model.Axes[0].Zoom(min, max);
        }

        private void EngineOP_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var min = EngineOP.Model.Axes[0].ActualMinimum;
            var max = EngineOP.Model.Axes[0].ActualMaximum;
            TimeDiffOP.Model.Axes[0].Zoom(min, max);
            SpeedOP.Model.Axes[0].Zoom(min, max);
            GForcesOP.Model.Axes[0].Zoom(min, max);
            RaceTrackOP.Model.Axes[0].Zoom(min, max);
            TimeDiffOP.OnModelChanged();
            SpeedOP.OnModelChanged();
            GForcesOP.OnModelChanged();
            RaceTrackOP.OnModelChanged();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    }
